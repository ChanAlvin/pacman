/**
 * Controls the movement of the player in game.
 * 
 * modified     20220620
 * date         20220531
 * @filename    Control.java
 * @author      Alvin Chan
 * @author      Hammad Hassan
 * @author      Oscar Lam
 * @version     1.0.0
 * @see         C1 - Culminating Project
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Control implements KeyListener, ActionListener{
	Pacman gui;
	Timer timer; 
	int timerCounter = 0;
	boolean move = false;
	int score = 0;
	int powerUpLeft = 400;

	public Control (Pacman in){
		gui = in;
		timer = new Timer(30, this);
		timer.start(); // start the time
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
		if(move == true) {
			if (e.getKeyCode() == 87) { // up
				if(gui.playerR-1>=0 && gui.map[gui.playerR-1][gui.playerC] == 0) {
					gui.total+=10;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerR--;
					gui.map[gui.playerR][gui.playerC] = 1;
					score += 10;
				}
				else if(gui.playerR-1>=0 && gui.map[gui.playerR-1][gui.playerC] == 7) {
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerR--;
					gui.map[gui.playerR][gui.playerC] = 1;
				}
				else if(gui.playerR-1>=0 && gui.map[gui.playerR-1][gui.playerC] == 8) {
					gui.killTime = 0;
					gui.playerKill = false;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerR--;
					gui.map[gui.playerR][gui.playerC] = 1;
					gui.playerKill = true;
					gui.ghostKill = false;
				}
				if(gui.playerKill) {
					if(gui.playerR-1>=0 && gui.map[gui.playerR-1][gui.playerC] == 4) {
						gui.redR = 10;
						gui.redC = 9;
						gui.map[gui.redR][gui.redC] = 4;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerR--;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.redBeeFirst = true;
						score += 50;
					}
					else if(gui.playerR-1>=0 && gui.map[gui.playerR-1][gui.playerC] == 5) {
						gui.greenR = 10;
						gui.greenC = 10;
						gui.map[gui.greenR][gui.greenC] = 5;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerR--;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.greenBeeFirst = true;
						score += 50;
					}
					else if(gui.playerR-1>=0 && gui.map[gui.playerR-1][gui.playerC] == 6) {
						gui.purpleR = 10;
						gui.purpleC = 11;
						gui.map[gui.purpleR][gui.purpleC] = 6;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerR--;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.purpleBeeFirst = true;
						score += 50;
					}
				}
				gui.pacman = new ImageIcon("Images//pacAntUp.png");
			} 
			else if (e.getKeyCode() == 83 ) { // down
				if(gui.playerR+1<gui.BOARD_SIZE && gui.map[gui.playerR+1][gui.playerC] == 0)
				{
					gui.total+=10;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerR++;
					gui.map[gui.playerR][gui.playerC] = 1;
					score += 10;
				}
				else if(gui.playerR+1<gui.BOARD_SIZE && gui.map[gui.playerR+1][gui.playerC] == 7){
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerR++;
					gui.map[gui.playerR][gui.playerC] = 1;
				}
				else if(gui.playerR+1<gui.BOARD_SIZE && gui.map[gui.playerR+1][gui.playerC] == 8){
					gui.killTime = 0;
					gui.playerKill = false;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerR++;
					gui.map[gui.playerR][gui.playerC] = 1;
					gui.playerKill = true;
					gui.ghostKill = false;
				}
				if(gui.playerKill) {
					if(gui.playerR+1<gui.BOARD_SIZE && gui.map[gui.playerR+1][gui.playerC] == 4) {
						gui.redR = 10;
						gui.redC = 9;
						gui.map[gui.redR][gui.redC] = 4;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerR++;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.redBeeFirst = true;
						score += 50;
					}
					else if(gui.playerR+1<gui.BOARD_SIZE && gui.map[gui.playerR+1][gui.playerC] == 5) {
						gui.greenR = 10;
						gui.greenC = 10;
						gui.map[gui.greenR][gui.greenC] = 5;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerR++;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.greenBeeFirst = true;
						score += 50;
					}
					else if(gui.playerR+1<gui.BOARD_SIZE && gui.map[gui.playerR+1][gui.playerC] == 6) {
						gui.purpleR = 10;
						gui.purpleC = 11;
						gui.map[gui.purpleR][gui.purpleC] = 6;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerR++;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.purpleBeeFirst = true;
						score += 50;
					}
				}
				gui.pacman = new ImageIcon("Images//pacAntDown.png");
			} 
			else if (e.getKeyCode() == 68) { // right
				if(gui.playerR == 10 && gui.playerC==20) {
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC = 0;
					gui.map[gui.playerR][gui.playerC] = 1;
				}
				else if(gui.playerC+1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC+1] == 0)
				{
					gui.total+=10;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC++;
					gui.map[gui.playerR][gui.playerC] = 1;
					score += 10;
				}
				else if(gui.playerC+1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC+1] == 7)
				{
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC++;
					gui.map[gui.playerR][gui.playerC] = 1;
				}
				else if(gui.playerC+1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC+1] == 8)
				{
					gui.killTime = 0;
					gui.playerKill = false;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC++;
					gui.map[gui.playerR][gui.playerC] = 1;
					gui.playerKill = true;
					gui.ghostKill = false;
				}
				if(gui.playerKill) {
					if(gui.playerC+1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC+1] == 4) {
						gui.redR = 10;
						gui.redC = 9;
						gui.map[gui.redR][gui.redC] = 4;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerC++;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.redBeeFirst = true;
						score += 50;
					}
					else if(gui.playerC+1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC+1] == 5) {
						gui.greenR = 10;
						gui.greenC = 10;
						gui.map[gui.greenR][gui.greenC] = 5;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerC++;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.greenBeeFirst = true;
						score += 50;
					}
					else if(gui.playerC+1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC+1] == 6) {
						gui.purpleR = 10;
						gui.purpleC = 11;
						gui.map[gui.purpleR][gui.purpleC] = 6;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerC++;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.purpleBeeFirst = true;
						score += 50;
					}
				}
				gui.pacman = new ImageIcon("Images//pacAntRight.png");
			} 
			else if (e.getKeyCode() == 65) { // left
				if(gui.playerR == 10 && gui.playerC==0) {
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC = 20;
					gui.map[gui.playerR][gui.playerC] = 1;
				}
				else if(gui.playerC-1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC-1] == 0) {
					gui.total+=10;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC--;
					gui.map[gui.playerR][gui.playerC] = 1;
					score += 10;
				}
				else if(gui.playerC-1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC-1] == 7) {
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC--;
					gui.map[gui.playerR][gui.playerC] = 1;
				}
				else if(gui.playerC-1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC-1] == 8) {
					gui.killTime = 0;
					gui.playerKill = false;
					gui.map[gui.playerR][gui.playerC] = 7;
					gui.playerC--;
					gui.map[gui.playerR][gui.playerC] = 1;
					gui.playerKill = true;
					gui.ghostKill = false;
				}
				if(gui.playerKill) {
					if(gui.playerC-1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC-1] == 4) {
						gui.redR = 10;
						gui.redC = 9;
						gui.map[gui.redR][gui.redC] = 4;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerC--;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.redBeeFirst = true;
						score += 50;
					}
					else if(gui.playerC-1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC-1]== 5) {
						gui.greenR = 10;
						gui.greenC = 10;
						gui.map[gui.greenR][gui.greenC] = 5;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerC--;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.greenBeeFirst = true;
						score += 50;
					}
					else if(gui.playerC-1<gui.BOARD_SIZE && gui.map[gui.playerR][gui.playerC-1] == 6) {
						gui.purpleR = 10;
						gui.purpleC = 11;
						gui.map[gui.purpleR][gui.purpleC] = 6;
						gui.map[gui.playerR][gui.playerC] = 7;
						gui.playerC--;
						gui.map[gui.playerR][gui.playerC] = 1;
						gui.ai.purpleBeeFirst = true;
						score += 50;
					}
				}
				gui.pacman = new ImageIcon("Images//pacAntLeft.png");
			} 
			gui.mapRead();
			timerCounter = 0;
			move = false;
		}
	}	

	public void keyReleased(KeyEvent e) {
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == timer ) { 
			timerCounter++;
			if(gui.playerKill) {
				gui.killTime++;
				gui.powerUpTime.setText("Time until powerup is gone: "+(powerUpLeft-gui.killTime));
			}
			gui.scoreboard.setText("Score: "+Integer.toString(score)+".");
		}
		if(timerCounter > 3) {
			move = true;
		}
		if(gui.killTime == 400) {
			gui.playerKill = false;
			gui.ghostKill = true;
		}
	}
}